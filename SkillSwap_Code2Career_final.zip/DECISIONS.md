# SkillSwap — Decision Points

## DP1 — Rejection
**Choice:** A declined booking remains visible to the client as **Declined**. The client can return to the marketplace and book another creator. This preserves a clear history of the request while keeping the client free to continue searching.

## DP2 — Double booking
**Choice:** A gig can receive multiple booking requests while another request is **Pending**. The creator reviews each request and chooses whether to accept or decline it, rather than the system blocking new requests automatically. This supports a marketplace where creators control their incoming work.

## DP3 — Discovery
**Choice:** Gigs are ranked **newest-first**. This gives newly posted services a predictable discovery path and keeps the marketplace fresh without making price the deciding factor.
