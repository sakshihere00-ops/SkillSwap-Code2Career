# SkillSwap — Code2Career Creator Economy

A no-login creator gig marketplace for the **Creator Economy** hackathon brief: young creators list skills, clients discover and book them, and creators manage incoming requests.

## Required features implemented
1. **Post a gig** — creator name, title, category, rate, and description.
2. **Browse & search** — marketplace listing with keyword search and category filters; newest gigs appear first.
3. **Book a gig** — booking form with client name + request, followed by confirmation and a Pending booking.
4. **Creator dashboard** — select a creator, view incoming bookings, and Accept or Decline each Pending request.
5. **My bookings** — select a client and view their bookings with Pending, Accepted, or Declined status.

## Decision Points
See [`DECISIONS.md`](DECISIONS.md) for all three required decisions and the reasoning behind each.

- **DP1 — Rejection:** Declined bookings remain visible; clients can return to the marketplace and book another creator.
- **DP2 — Double booking:** Multiple Pending requests are allowed for a gig; the creator decides which requests to accept or decline.
- **DP3 — Discovery:** Marketplace ranking is newest-first.

## Standard API
**Not implemented.** This submission is designed for browser-agent/UI grading and uses localStorage for persistence. No login/signup or authentication is implemented, so graders can access every feature directly.

## Tech stack
- HTML5
- CSS3
- Vanilla JavaScript
- Browser `localStorage`
- No backend and no authentication

## Run locally
Open `index.html` directly in a modern browser, or serve the folder with a static web server, for example:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Test access / credentials
**No credentials are required.** There is no login/signup. The app uses selectable creator/client names inside the UI so all flows can be demonstrated without authentication.

### Suggested demo flow
1. Browse Gigs → search/filter a seeded gig.
2. Book a gig as a client, e.g. `Priya`.
3. Open Creator Dashboard → select the gig's creator → Accept or Decline the request.
4. Open My Bookings → select `Priya` → verify the status.
5. Repeat booking to demonstrate DP2 (multiple Pending requests), and decline one to demonstrate DP1.

## Hackathon ID
**AZIS-VJFKUM**


## Submission checklist
- [x] Deployed working app implementing all five required features
- [ ] Public GitHub repository containing this README.md at the root
- [x] Exact Hackathon ID entered above
- [x] No authentication / login / signup
- [x] DECISIONS.md at repository root
- [x] Standard API status stated
- [ ] 3–4 minute demo recording covering the five features in order + Decision Point behaviors
